package com.cun.service;

import java.util.List;

import com.cun.dao.StudentDao;
import com.cun.entity.Student;

public interface StudentService {

    public void addStudent(Student student);
    public void deleteStudent(Integer id);
    public void updateStudent(Student student);
    public StudentDao findStudent( Integer id);
    public List<Student> findAllStudent();

}

