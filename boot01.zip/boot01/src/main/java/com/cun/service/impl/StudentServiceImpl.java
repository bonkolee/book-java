package com.cun.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cun.dao.StudentDao;
import com.cun.entity.Student;
import com.cun.service.StudentService;
import org.springframework.web.bind.annotation.GetMapping;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao studentDao;

    @Override
    public void addStudent(Student student) {
        // TODO Auto-generated method stub
        studentDao.save(student);
    }

    @Override
    public void deleteStudent( Integer id) {
        // TODO Auto-generated method stub
       // studentDao.delete(id);

    }

    @Override
    public void updateStudent(Student student) {
        // TODO Auto-generated method stub
        studentDao.save(student);
    }

    @Override
    public StudentDao findStudent( Integer id) {
        // TODO Auto-generated method stub
        return studentDao;

    }

    @Override
    public List<Student> findAllStudent() {
        // TODO Auto-generated method stub
        return studentDao.findAll();

    }



}

